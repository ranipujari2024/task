<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;
use Yajra\DataTables\DataTables;

class ProductController extends Controller
{

    public function getAllProduct()
    {
        return view('product.all');
    }

    public function getAllProductData()
    {
        // $product = Product::orderBy('id','ASC');
        // return DataTables::of($product)->make(true);

        $products = Product::orderBy('id', 'ASC')->get();

    return DataTables::of($products)
        ->editColumn('description', function ($product) {
            return $product->description; // Return as-is, make sure it's in raw HTML format
        })
        ->make(true);
    }

    public function getAddProduct() 
    {
        return view('product.add');
    }

    public function postProduct(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'amount' => 'required|numeric',
            'description' => 'required',
            'image' => 'nullable|mimes:jpeg,jpg,png|max:2048'
        ]);

        $product=new Product();
        $product->name=$request->name;
        $product->amount=$request->amount;
        $product->description=$request->description;
        if(isset($request->image)){
            $path = $request->file('image')->store("testimage");   
            $product->image=$path;
        }
        $product->save(); 
        $notification = array(
            'message' => 'Product added successfully', 
            'alert-type' => 'success'
        );
        return redirect('product/all')->with($notification);
    }

    public function getEditProduct($product_id)
    {
        $product=Product::where('id',$product_id)->first();
        return view('product.edit')->with('product',$product);
    }

    public function postEditProduct(Request $request,$product_id)
    {  
        $request->validate([
            'name' => 'required',
            'amount' => 'required|numeric',
            'description' => 'required',
            'image' => 'nullable|mimes:jpeg,jpg,png|max:2048'
        ]);

        $product = Product::where('id',$product_id)->first();
        $product->name=$request->name;
        $product->amount=$request->amount;
        $product->description=$request->description;
        if(isset($request->image)){
            $filename = "storage/app/testimage" . $product->image;
            if ($product->image != null && $filename) {
                unlink('storage/app/'.$product->image);
            }
            $path = $request->file('image')->store("testimage");   
            $product->image=$path;
        }
        $product->save(); 
        $notification = array(
            'message' => 'Product updated successfully', 
            'alert-type' => 'success',
            'position' => 'right-bottom'
        );
        return redirect('product/all')->with($notification);
    }

    public function getViewProduct($product_id)
    {
        $product=Product::where('id',$product_id)->first();
        return view('product.view')->with('product',$product);
    }

}
