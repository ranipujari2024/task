@extends('layouts.app')
@section('content')
<style type="text/css">
    .note-toolbar{
        display: none;
    }
    .note-statusbar{
        display: none;
    }
    .note-editor.note-frame, .note-editor.note-airframe {
        border: none;
    }
    p {
        margin-top: 0;
        margin-bottom: 0;
    }
    .note-editable{
/*        overflow: var(--bs-scroll-display, none) !important;*/
}
.nk-chat {
  height: 75vh !important;
  top: 12px;
}
</style>
<div class="nk-block-head nk-block-head-sm">
    <div class="nk-block-between g-3">
        <div class="nk-block-head-content">
            <h3 class="nk-block-title page-title">Product Details</h3>
        </div>  
        <div class="nk-block-head-content">
            <a href="{{ url('product/all') }}" class="btn btn-outline-light bg-white d-none d-sm-inline-flex"><em class="icon ni ni-arrow-left"></em><span>Back</span></a>
        </div>
    </div>
</div><!-- .nk-block-head -->
<div class="nk-block">
    <div class="card">
        <div class="card-inner">
            <div class="row pb-5">
                @if($product->image != null)
                <div class="col-lg-6">
                    <div class="product-gallery me-xl-1 me-xxl-5">
                        <div class="slider-item rounded">
                            <img src="{{ config('app.baseURL') . '/storage/app/' . $product->image }}" class="rounded w-100" alt="">
                        </div>
                    </div><!-- .product-gallery -->
                </div><!-- .col -->
                @endif
                <div class="col-lg-6">
                    <div class="product-info mt-5 me-xxl-5">
                        <h4 class="product-price text-primary">Rs. {{$product->amount}}/-</h4>
                        <h2 class="product-title">{{$product->name}}</h2>
                        <div class="product-excrept text-soft">
                            <p class="lead">{!! $product->description !!}</p>
                        </div>
                    </div><!-- .product-info -->
                </div><!-- .col -->
            </div><!-- .row -->
            <hr class="hr border-light">
        </div>
    </div>
</div><!-- .nk-block -->
@endsection
